# Parsha + Targumim reader — Sefaria-only builder

Same reading page as before (Hebrew text, Onkelos, Pseudo-Jonathan, Targum
Yerushalmi fragments, Rashi, English where Sefaria has it, font/size
controls, dark mode, aliyah jump-nav). This version gets everything —
*which* parsha, the aliyah boundaries, and the actual texts — from a single
source: **Sefaria**. No second provider, no config file to fill in.

## Why Sefaria alone

Their own homepage shows a "this week's parasha" quick link, so they
obviously have the aliyah data internally — and it turns out it's public:
Sefaria's **Calendars API** (`/api/calendars`) returns the current parsha,
its verse range, and all 7 aliyot directly, as part of the same data that
powers the homepage link. Confirmed against Sefaria's own published example
in their developer tutorial (a real response for Parashat Mishpatim) — this
script's parsing was tested against that exact example and reproduces it
correctly.

The actual texts still come from Sefaria's **bulk data export** on GitHub,
same as before — their own docs recommend that over the live API for this
kind of repeated use.

## One-time setup

Install **Python 3** and **git**. No `pip install` needed.

## Running it

For building everything at once (the intended once-a-year workflow):

```
python3 build_parsha.py --year
```

Builds the next 55 weeks of parshiot (enough to cover a full annual cycle
with room to spare), each as its own page, plus an `index.html` with:
- a **"this week's parsha"** button at the top (computed client-side by
  comparing today's date against each page's date — works correctly however
  long ago you ran the script, as long as it's within the year you built), and
- a plain list of every parsha, for picking one manually.

Every individual page also gets a thin nav row: a link back to the index,
and ‹ previous / next › links to move between adjacent weeks — so once
you're on a page you don't need to go back to the index to move around.

First run clones Sefaria's data (sparse — just Torah/Targum/Rashi) into
`./Sefaria-Export/`. One-time download; later runs reuse it. Output lands
in `site/` — one `.html` per parsha, plus `index.html`.

**Rate limiting:** pulling ~55 weeks hits Sefaria's calendar API 55 times.
Each successful lookup is cached to disk under `calendar_cache/` (a Shabbat's
parsha never changes, so this is safe to keep forever) — if a run fails
partway through, re-running only fetches what's still missing. If you get
HTTP 429 errors, the script retries automatically with increasing delays
(2s, 4s, 8s... capped at 30s, up to 8 attempts per date). If it still fails
immediately on a fresh run, Sefaria's cooldown window may be longer than a
few seconds — wait 10–15 minutes before trying again rather than re-running
repeatedly.

Other modes, if you want a single week instead of the whole year:
```
python3 build_parsha.py --list              # see what's coming up, with dates
python3 build_parsha.py --next              # build just this/next Shabbat's parsha
python3 build_parsha.py --date 2026-10-10   # build whatever week that date falls in
```
(These write a single file and don't touch `index.html` — only `--year`
builds/updates the index.)

## Reading one page offline (e.g. on a flight)

There's a ✈️ button on every page that shows a reminder, because there's no
way for a webpage's own code to trigger this — it has to go through your
browser: in **Chrome on Android**, open the page while you still have
signal, tap the **⋮ menu → Download**. Chrome saves a full offline copy you
can reopen later from the Downloads app, no connection needed. Do this
before you lose signal, not after.

This is deliberately not an automatic "works offline always" setup (you
said you don't need that routinely) — it's just making sure the one-page,
occasional case is easy to remember.

## What I tested vs. what I couldn't

I don't have live network access to either sefaria.org or GitHub from where
I generated this, so I verified it in parts rather than end-to-end live:

- **Calendar parsing** — tested against Sefaria's own published example
  response (Parashat Mishpatim, including its oddball maftir-from-Numbers
  case) and it reconstructs the correct parsha, book, and 7 aliyot, correctly
  ignoring the 8th (maftir) entry.
- **Text extraction** — tested against the real Sefaria data (cloned
  locally) using a simulated Bereshit calendar response, and it reproduces
  the exact same 146 verses / 98 Rashi comments / 22 Onkelos-English matches
  we built by hand earlier this session.
- **The `--year` loop, nav links, and index page** — tested with a simulated
  2-week sequence (Bereshit → a fake holiday gap → Noach) against the real
  Sefaria text data: confirmed the holiday week gets skipped with a message
  rather than breaking anything, the prev/next links on each page point to
  the right neighboring file, and the index page's embedded data and "this
  week" JS logic are both syntactically valid and structurally correct.
- **Not tested**: an actual live call to `sefaria.org/api/calendars`. The
  URL format and response shape are Sefaria's own documented ones, but
  that's not a substitute for actually running it — worth doing once on
  your machine before relying on it unattended (`--list` is a quick,
  low-stakes first check, and it'll tell you quickly if something about the
  live API doesn't match what's documented).

## Known limitations, by design

- **No "תרגום לעברית" (Hebrew paraphrase) toggle.** No data source for it —
  it would mean someone translating the Aramaic by hand, verse by verse.
  English (Sefaria's own translations) and Rashi are both still included.
- **English for Onkelos** is missing for some chapters in some books —
  Sefaria's own translation coverage is incomplete in places (confirmed for
  Genesis 1–5). The page shows "No English available for this verse" rather
  than leaving a silent gap.
- **Shabbatot that fall during a holiday** (where a special festival reading
  replaces the week's regular parsha) are skipped rather than guessed at —
  you'll see a line printed for each one. Across a year this should still
  leave you with all ~54 parshiot, since the annual cycle already accounts
  for these weeks via the doubled-up portions (e.g. Vayakhel-Pekudei) — but
  I haven't run this live over a real full year to confirm that lines up
  perfectly.
- **Weeks where the 7 regular aliyot span more than one Torah book** aren't
  handled — the script prints a message and skips rather than guessing
  wrong. This is rare; ordinary joined double-parshiot (like
  Vayakhel-Pekudei) stay within one book and work normally.

## Hosting it on your phone — GitHub Pages

One-time setup:
1. Create a repo on GitHub.
2. Repo settings → **Pages** → source: the `site/` folder on your main branch.
3. In this project folder:
   ```
   git init
   git remote add origin <your-repo-url>
   git add site/
   git commit -m "add bereshit"
   git push -u origin main
   ```

Each week after:
```
python3 build_parsha.py --next
git add site/
git commit -m "weekly parsha"
git push
```

Open `https://<you>.github.io/<repo>/<parsha>.html` on your phone.

Prefer zero git commands? Drag the `site/` folder onto **netlify.com**'s
drop-zone for an instant live URL instead.
